# Быстрый старт - Сборка пакетов AppAlchemist

## 1. Сохраните иконку

Сохраните предоставленное изображение иконки как:
```
assets/icons/appalchemist.png
```

Рекомендуемый размер: 256x256 пикселей, формат PNG.

## 2. Соберите пакеты

### DEB (Debian/Ubuntu)
```bash
./packaging/build-deb.sh
```
Результат: `build/appalchemist_1.0.0-1_amd64.deb`

### RPM (Fedora/RHEL)
```bash
./packaging/build-rpm.sh
```
Результат: `build/rpmbuild/RPMS/x86_64/appalchemist-1.0.0-1.x86_64.rpm`

### Arch Linux
```bash
cd packaging/arch
./build-arch.sh
```
Результат: `appalchemist-1.0.0-1-x86_64.pkg.tar.zst`

## 3. Установите пакет

### DEB
```bash
sudo dpkg -i build/appalchemist_1.0.0-1_amd64.deb
```

### RPM
```bash
sudo rpm -ivh build/rpmbuild/RPMS/x86_64/appalchemist-1.0.0-1.x86_64.rpm
```

### Arch
```bash
sudo pacman -U appalchemist-1.0.0-1-x86_64.pkg.tar.zst
```

## Примечания

- Иконка опциональна - пакеты соберутся и без неё
- Все скрипты автоматически включат иконку, если она находится в `assets/icons/appalchemist.png`
- Desktop файл будет создан автоматически для всех пакетов
