# Сборка всех пакетов AppAlchemist

## Требования

### Для DEB пакета:
- `debhelper` (>= 13)
- `cmake` (>= 3.15)
- `qt6-base-dev`
- `dpkg-buildpackage`

### Для RPM пакета:
- `rpm-build`
- `cmake` (>= 3.15)
- `qt6-qtbase-devel`
- `rpmbuild`

### Для Arch пакета:
- `base-devel`
- `cmake` (>= 3.15)
- `qt6-base`
- `makepkg`

## Шаг 1: Сохраните иконку

См. файл `SAVE_ICON.md` для инструкций по сохранению иконки приложения.

## Шаг 2: Соберите пакеты

### Debian/Ubuntu (.deb)
```bash
cd /home/mozze0/keyring/deb-to-appimage
./packaging/build-deb.sh
```

Результат: `build/appalchemist_1.0.0-1_amd64.deb`

### Fedora/RHEL/CentOS (.rpm)
```bash
cd /home/mozze0/keyring/deb-to-appimage
./packaging/build-rpm.sh
```

Результат: `build/rpmbuild/RPMS/x86_64/appalchemist-1.0.0-1.x86_64.rpm`

### Arch Linux (PKGBUILD)
```bash
cd /home/mozze0/keyring/deb-to-appimage/packaging/arch
./build-arch.sh
```

Или вручную:
```bash
cd /home/mozze0/keyring/deb-to-appimage/packaging/arch
makepkg -si
```

Результат: `appalchemist-1.0.0-1-x86_64.pkg.tar.zst`

## Установка пакетов

### DEB
```bash
sudo dpkg -i build/appalchemist_1.0.0-1_amd64.deb
sudo apt-get install -f  # Установить зависимости если нужно
```

### RPM
```bash
sudo rpm -ivh build/rpmbuild/RPMS/x86_64/appalchemist-1.0.0-1.x86_64.rpm
```

### Arch
```bash
sudo pacman -U appalchemist-1.0.0-1-x86_64.pkg.tar.zst
```

## Проверка

После установки приложение должно быть доступно:
- В меню приложений как "AppAlchemist"
- Из командной строки: `appalchemist`

