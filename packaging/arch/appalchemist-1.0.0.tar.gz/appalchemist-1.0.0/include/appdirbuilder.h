#ifndef APPDIRBUILDER_H
#define APPDIRBUILDER_H

#include "debparser.h"
#include <QString>
#include <QStringList>

class AppDirBuilder {
public:
    AppDirBuilder();
    
    bool buildAppDir(const QString& appDirPath,
                     const QString& extractedDebDir,
                     const DebMetadata& metadata,
                     const QStringList& libraries);
    
    bool createDesktopFile(const QString& appDirPath, const DebMetadata& metadata);
    bool fixDesktopFile(const QString& desktopPath);
    bool copyIcon(const QString& appDirPath, const QString& iconPath, const DebMetadata& metadata);
    bool createAppRun(const QString& appDirPath, const DebMetadata& metadata);
    
private:
    bool createDirectoryStructure(const QString& appDirPath);
    bool copyExecutables(const QString& appDirPath, 
                        const QString& extractedDebDir,
                        const QStringList& executables);
    bool copyLibraries(const QString& appDirPath, const QStringList& libraries);
    bool copyResources(const QString& appDirPath, const QString& extractedDebDir);
};

#endif // APPDIRBUILDER_H

