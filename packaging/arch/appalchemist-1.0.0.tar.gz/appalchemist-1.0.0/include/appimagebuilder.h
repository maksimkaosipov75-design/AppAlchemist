#ifndef APPIMAGEBUILDER_H
#define APPIMAGEBUILDER_H

#include <QObject>
#include <QString>

class AppImageBuilder : public QObject {
    Q_OBJECT

public:
    explicit AppImageBuilder(QObject* parent = nullptr);
    
    bool buildAppImage(const QString& appDirPath, const QString& outputPath);
    QString findAppImageTool();

signals:
    void log(const QString& message);

private:
    QString m_appImageToolPath;
    bool checkAppImageTool(const QString& path);
};

#endif // APPIMAGEBUILDER_H
