#include "appmainwindow.h"
#include <QApplication>
#include <QStyleFactory>
#include <QDir>

int main(int argc, char* argv[]) {
    QApplication app(argc, argv);
    
    app.setApplicationName("AppAlchemist");
    app.setApplicationVersion("1.0.0");
    app.setOrganizationName("AppAlchemist");
    
    // Set application style
    app.setStyle(QStyleFactory::create("Fusion"));
    
    AppMainWindow window;
    window.show();
    
    return app.exec();
}

