#include "appmainwindow.h"
#include <QApplication>
#include <QMessageBox>
#include <QDir>
#include <QFileInfo>
#include <QDesktopServices>
#include <QUrl>
#include <QStyle>
#include <QPalette>
#include <QTextCursor>
#include <QMouseEvent>

AppMainWindow::AppMainWindow(QWidget* parent)
    : QMainWindow(parent)
    , m_isProcessing(false)
    , m_pipeline(nullptr)
    , m_pipelineThread(nullptr)
{
    setWindowTitle("AppAlchemist - Package to AppImage Converter");
    setMinimumSize(800, 600);
    resize(900, 700);
    
    setupUI();
    resetUI();
}

AppMainWindow::~AppMainWindow() {
    if (m_pipelineThread) {
        m_pipelineThread->quit();
        m_pipelineThread->wait();
        delete m_pipelineThread;
    }
    if (m_pipeline) {
        delete m_pipeline;
    }
}

void AppMainWindow::setupUI() {
    m_centralWidget = new QWidget(this);
    setCentralWidget(m_centralWidget);
    
    m_mainLayout = new QVBoxLayout(m_centralWidget);
    m_mainLayout->setSpacing(15);
    m_mainLayout->setContentsMargins(20, 20, 20, 20);
    
    // Title
    QLabel* titleLabel = new QLabel("AppAlchemist", this);
    QFont titleFont = titleLabel->font();
    titleFont.setPointSize(18);
    titleFont.setBold(true);
    titleLabel->setFont(titleFont);
    titleLabel->setAlignment(Qt::AlignCenter);
    m_mainLayout->addWidget(titleLabel);
    
    // Drag and drop area
    m_dropArea = new QLabel(this);
    m_dropArea->setMinimumHeight(150);
    m_dropArea->setStyleSheet(
        "QLabel {"
        "border: 3px dashed #999;"
        "border-radius: 10px;"
        "background-color: #f5f5f5;"
        "padding: 20px;"
        "}"
        "QLabel:hover {"
        "border-color: #0078d4;"
        "background-color: #e8f4f8;"
        "}"
    );
    m_dropArea->setAlignment(Qt::AlignCenter);
    m_dropArea->setAcceptDrops(true);
    m_dropArea->setText("Drag and drop a .deb or .rpm file here\nor click to select a file");
    m_dropArea->setWordWrap(true);
    m_dropArea->installEventFilter(this);
    m_mainLayout->addWidget(m_dropArea);
    
    // File label
    m_fileLabel = new QLabel("No file selected", this);
    m_fileLabel->setAlignment(Qt::AlignCenter);
    m_fileLabel->setStyleSheet("color: #666; font-style: italic;");
    m_mainLayout->addWidget(m_fileLabel);
    
    // Output directory selection
    QHBoxLayout* outputLayout = new QHBoxLayout();
    QLabel* outputLabel = new QLabel("Output directory:", this);
    m_outputDirLabel = new QLabel(QDir::homePath(), this);
    m_outputDirLabel->setStyleSheet("padding: 5px; background-color: #f0f0f0; border-radius: 3px;");
    m_outputDirLabel->setMinimumHeight(25);
    m_selectOutputDirButton = new QPushButton("Browse...", this);
    connect(m_selectOutputDirButton, &QPushButton::clicked, this, &AppMainWindow::onSelectOutputDirClicked);
    outputLayout->addWidget(outputLabel);
    outputLayout->addWidget(m_outputDirLabel, 1);
    outputLayout->addWidget(m_selectOutputDirButton);
    m_mainLayout->addLayout(outputLayout);
    
    // Build button
    m_buildButton = new QPushButton("Build AppImage", this);
    m_buildButton->setMinimumHeight(40);
    m_buildButton->setStyleSheet(
        "QPushButton {"
        "background-color: #0078d4;"
        "color: white;"
        "font-weight: bold;"
        "border-radius: 5px;"
        "padding: 10px;"
        "}"
        "QPushButton:hover {"
        "background-color: #106ebe;"
        "}"
        "QPushButton:disabled {"
        "background-color: #ccc;"
        "color: #666;"
        "}"
    );
    connect(m_buildButton, &QPushButton::clicked, this, &AppMainWindow::onBuildClicked);
    m_mainLayout->addWidget(m_buildButton);
    
    // Progress bar
    m_progressBar = new QProgressBar(this);
    m_progressBar->setMinimum(0);
    m_progressBar->setMaximum(100);
    m_progressBar->setValue(0);
    m_progressBar->setTextVisible(true);
    m_progressBar->setFormat("%p% - %v");
    m_mainLayout->addWidget(m_progressBar);
    
    // Status label
    m_statusLabel = new QLabel("Ready", this);
    m_statusLabel->setAlignment(Qt::AlignCenter);
    m_statusLabel->setStyleSheet("font-weight: bold; padding: 5px;");
    m_mainLayout->addWidget(m_statusLabel);
    
    // Log area
    QLabel* logLabel = new QLabel("Log:", this);
    m_logText = new QTextEdit(this);
    m_logText->setReadOnly(true);
    m_logText->setMinimumHeight(200);
    m_logText->setFont(QFont("Monospace", 9));
    m_logText->setStyleSheet(
        "QTextEdit {"
        "background-color: #1e1e1e;"
        "color: #d4d4d4;"
        "border: 1px solid #3e3e3e;"
        "border-radius: 5px;"
        "padding: 5px;"
        "}"
    );
    m_mainLayout->addWidget(logLabel);
    m_mainLayout->addWidget(m_logText, 1);
    
    // Open output directory button
    m_openOutputDirButton = new QPushButton("Open Output Directory", this);
    m_openOutputDirButton->setEnabled(false);
    connect(m_openOutputDirButton, &QPushButton::clicked, this, &AppMainWindow::onOpenOutputDirClicked);
    m_mainLayout->addWidget(m_openOutputDirButton);
}

void AppMainWindow::dragEnterEvent(QDragEnterEvent* event) {
    if (event->mimeData()->hasUrls() && !m_isProcessing) {
        QList<QUrl> urls = event->mimeData()->urls();
        if (!urls.isEmpty()) {
            QString filePath = urls.first().toLocalFile();
            QFileInfo info(filePath);
            QString suffix = info.suffix().toLower();
            if (suffix == "deb" || suffix == "rpm") {
                event->acceptProposedAction();
                m_dropArea->setStyleSheet(
                    "QLabel {"
                    "border: 3px dashed #0078d4;"
                    "border-radius: 10px;"
                    "background-color: #e8f4f8;"
                    "padding: 20px;"
                    "}"
                );
            }
        }
    }
}

void AppMainWindow::dropEvent(QDropEvent* event) {
    m_dropArea->setStyleSheet(
        "QLabel {"
        "border: 3px dashed #999;"
        "border-radius: 10px;"
        "background-color: #f5f5f5;"
        "padding: 20px;"
        "}"
        "QLabel:hover {"
        "border-color: #0078d4;"
        "background-color: #e8f4f8;"
        "}"
    );
    
    if (event->mimeData()->hasUrls() && !m_isProcessing) {
        QList<QUrl> urls = event->mimeData()->urls();
        if (!urls.isEmpty()) {
            QString filePath = urls.first().toLocalFile();
            QFileInfo info(filePath);
            QString suffix = info.suffix().toLower();
            if (suffix == "deb" || suffix == "rpm") {
                setPackageFile(filePath);
                event->acceptProposedAction();
            }
        }
    }
}

void AppMainWindow::setPackageFile(const QString& filePath) {
    m_packageFilePath = filePath;
    QFileInfo info(filePath);
    m_fileLabel->setText(QString("Selected: %1").arg(info.fileName()));
    m_fileLabel->setStyleSheet("color: #0078d4; font-weight: bold;");
    m_buildButton->setEnabled(true);
}

void AppMainWindow::onSelectOutputDirClicked() {
    QString dir = QFileDialog::getExistingDirectory(this, "Select Output Directory", m_outputDir);
    if (!dir.isEmpty()) {
        m_outputDir = dir;
        m_outputDirLabel->setText(dir);
    }
}

void AppMainWindow::onBuildClicked() {
    if (m_packageFilePath.isEmpty()) {
        QMessageBox::warning(this, "No file selected", "Please select a .deb or .rpm file first.");
        return;
    }
    
    if (m_isProcessing) {
        if (m_pipeline) {
            m_pipeline->cancel();
        }
        return;
    }
    
    resetUI();
    m_isProcessing = true;
    enableControls(false);
    m_buildButton->setText("Cancel");
    m_statusLabel->setText("Processing...");
    m_statusLabel->setStyleSheet("font-weight: bold; color: #0078d4; padding: 5px;");
    
    // Create pipeline in separate thread
    m_pipelineThread = new QThread(this);
    m_pipeline = new PackageToAppImagePipeline();
    m_pipeline->moveToThread(m_pipelineThread);
    
    connect(m_pipelineThread, &QThread::started, m_pipeline, &PackageToAppImagePipeline::start);
    connect(m_pipeline, &PackageToAppImagePipeline::progress, this, &AppMainWindow::onProgress);
    connect(m_pipeline, &PackageToAppImagePipeline::log, this, &AppMainWindow::onLog);
    connect(m_pipeline, &PackageToAppImagePipeline::error, this, &AppMainWindow::onError);
    connect(m_pipeline, &PackageToAppImagePipeline::success, this, &AppMainWindow::onSuccess);
    connect(m_pipeline, &PackageToAppImagePipeline::finished, this, &AppMainWindow::onPipelineFinished);
    connect(m_pipelineThread, &QThread::finished, m_pipeline, &QObject::deleteLater);
    
    // Set paths
    m_pipeline->setPackagePath(m_packageFilePath);
    if (!m_outputDir.isEmpty()) {
        QFileInfo packageInfo(m_packageFilePath);
        QString appImagePath = QString("%1/%2.AppImage")
            .arg(m_outputDir)
            .arg(packageInfo.baseName());
        m_pipeline->setOutputPath(appImagePath);
    }
    
    m_pipelineThread->start();
}

void AppMainWindow::onProgress(int percentage, const QString& message) {
    m_progressBar->setValue(percentage);
    m_statusLabel->setText(message);
}

void AppMainWindow::onLog(const QString& message) {
    m_logText->append(message);
    QTextCursor cursor = m_logText->textCursor();
    cursor.movePosition(QTextCursor::End);
    m_logText->setTextCursor(cursor);
}

void AppMainWindow::onError(const QString& errorMessage) {
    m_statusLabel->setText("Error: " + errorMessage);
    m_statusLabel->setStyleSheet("font-weight: bold; color: #d32f2f; padding: 5px;");
    QMessageBox::critical(this, "Error", errorMessage);
}

void AppMainWindow::onSuccess(const QString& appImagePath) {
    m_statusLabel->setText("Success! AppImage created.");
    m_statusLabel->setStyleSheet("font-weight: bold; color: #2e7d32; padding: 5px;");
    m_openOutputDirButton->setEnabled(true);
    
    QMessageBox::information(this, "Success", 
        QString("AppImage created successfully!\n\n%1").arg(appImagePath));
}

void AppMainWindow::onPipelineFinished() {
    m_isProcessing = false;
    enableControls(true);
    m_buildButton->setText("Build AppImage");
    m_buildButton->setEnabled(!m_packageFilePath.isEmpty());
    
    if (m_pipelineThread) {
        m_pipelineThread->quit();
        m_pipelineThread->wait();
        delete m_pipelineThread;
        m_pipelineThread = nullptr;
    }
    m_pipeline = nullptr;
}

void AppMainWindow::onOpenOutputDirClicked() {
    QString dir = m_outputDir.isEmpty() ? QDir::homePath() : m_outputDir;
    QDesktopServices::openUrl(QUrl::fromLocalFile(dir));
}

bool AppMainWindow::eventFilter(QObject* obj, QEvent* event) {
    if (obj == m_dropArea && event->type() == QEvent::MouseButtonPress && !m_isProcessing) {
        QMouseEvent* mouseEvent = static_cast<QMouseEvent*>(event);
        if (mouseEvent->button() == Qt::LeftButton) {
            QString filePath = QFileDialog::getOpenFileName(this, 
                "Select package file", 
                QDir::homePath(),
                "Package files (*.deb *.rpm);;Debian packages (*.deb);;RPM packages (*.rpm)");
            if (!filePath.isEmpty()) {
                setPackageFile(filePath);
            }
            return true;
        }
    }
    return QMainWindow::eventFilter(obj, event);
}

void AppMainWindow::resetUI() {
    m_progressBar->setValue(0);
    m_statusLabel->setText("Ready");
    m_statusLabel->setStyleSheet("font-weight: bold; padding: 5px;");
    m_logText->clear();
    m_openOutputDirButton->setEnabled(false);
}

void AppMainWindow::enableControls(bool enabled) {
    m_selectOutputDirButton->setEnabled(enabled);
    // Don't disable build button - it becomes cancel button
}

