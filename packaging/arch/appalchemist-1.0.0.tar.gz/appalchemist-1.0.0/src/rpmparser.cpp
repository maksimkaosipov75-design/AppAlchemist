#include "rpmparser.h"
#include "utils.h"
#include <QDir>
#include <QFileInfo>
#include <QFile>
#include <QTextStream>
#include <QStandardPaths>
#include <QDebug>
#include <QRegularExpression>
#include <QDateTime>
#include <QIODevice>

RpmParser::RpmParser() {
    QString tempBase = QStandardPaths::writableLocation(QStandardPaths::TempLocation);
    m_tempDir = QString("%1/appalchemist-rpm-%2").arg(tempBase).arg(QString::number(QDateTime::currentMSecsSinceEpoch()));
}

RpmParser::~RpmParser() {
    if (!m_tempDir.isEmpty() && QDir(m_tempDir).exists()) {
        SubprocessWrapper::removeDirectory(m_tempDir);
    }
}

bool RpmParser::validateRpmFile(const QString& rpmPath) {
    QFileInfo info(rpmPath);
    if (!info.exists() || !info.isFile()) {
        return false;
    }
    
    // Check extension
    if (!info.suffix().toLower().endsWith("rpm")) {
        return false;
    }
    
    // Check magic number (RPM packages start with "ed ab ee db" or "drpm")
    QFile file(rpmPath);
    if (!file.open(QIODevice::ReadOnly)) {
        return false;
    }
    
    QByteArray header = file.read(4);
    file.close();
    
    // RPM magic numbers: 0xed 0xab 0xee 0xdb (old) or "drpm" (new)
    if (header.size() >= 4 && 
        ((header[0] == (char)0xed && header[1] == (char)0xab && 
          header[2] == (char)0xee && header[3] == (char)0xdb) ||
         header.startsWith("drpm"))) {
        return true;
    }
    
    return false;
}

bool RpmParser::extractRpm(const QString& rpmPath, const QString& extractDir) {
    if (!validateRpmFile(rpmPath)) {
        return false;
    }
    
    // Create extraction directory
    if (!SubprocessWrapper::createDirectory(extractDir)) {
        return false;
    }
    
    // Extract RPM using rpm2cpio and cpio
    // First, try to use rpm2cpio if available
    QString cpioDir = QString("%1/cpio").arg(extractDir);
    if (!SubprocessWrapper::createDirectory(cpioDir)) {
        return false;
    }
    
    // Check if rpm2cpio is available
    ProcessResult checkRpm2cpio = SubprocessWrapper::execute("which", {"rpm2cpio"});
    bool hasRpm2cpio = checkRpm2cpio.success && !checkRpm2cpio.stdoutOutput.trimmed().isEmpty();
    
    QString extractPath = QString("%1/data").arg(extractDir);
    if (!SubprocessWrapper::createDirectory(extractPath)) {
        return false;
    }
    
    if (hasRpm2cpio) {
        // Use rpm2cpio | cpio
        ProcessResult rpm2cpioResult = SubprocessWrapper::execute("rpm2cpio", {rpmPath});
        if (!rpm2cpioResult.success) {
            qWarning() << "rpm2cpio failed:" << rpm2cpioResult.errorMessage;
            return false;
        }
        
        // Pipe rpm2cpio output to cpio
        // We need to use a shell for piping
        QStringList cpioArgs = {"-idmv"};
        ProcessResult cpioResult = SubprocessWrapper::execute("sh", {
            "-c", 
            QString("rpm2cpio '%1' | cpio -idmv -D '%2'").arg(rpmPath).arg(extractPath)
        });
        
        if (!cpioResult.success) {
            qWarning() << "cpio extraction failed:" << cpioResult.errorMessage;
            return false;
        }
    } else {
        // Fallback: try using rpm command directly
        ProcessResult rpmResult = SubprocessWrapper::execute("rpm", {
            "--query", "--package", "--list", rpmPath
        });
        
        if (!rpmResult.success) {
            // Last resort: try using 7z or unzip (some RPMs can be extracted this way)
            ProcessResult sevenZipResult = SubprocessWrapper::execute("7z", {
                "x", rpmPath, "-o" + extractPath
            });
            
            if (!sevenZipResult.success) {
                qWarning() << "ERROR: Cannot extract RPM. Please install rpm2cpio or rpm tools.";
                return false;
            }
        } else {
            // Use rpm to extract
            ProcessResult extractResult = SubprocessWrapper::execute("rpm", {
                "--install", "--root", extractPath, "--nodeps", "--notriggers", "--noscripts", rpmPath
            }, extractPath);
            
            if (!extractResult.success) {
                qWarning() << "RPM extraction failed:" << extractResult.errorMessage;
                return false;
            }
        }
    }
    
    return true;
}

PackageMetadata RpmParser::parseMetadata(const QString& extractDir) {
    PackageMetadata metadata;
    
    // RPM stores metadata in .spec file or we can query it from the package
    // For extracted packages, we look for .spec files or parse file structure
    
    // Find .desktop file first (for Java apps and proper entry point)
    QString desktopFile = findDesktopFile(extractDir);
    if (!desktopFile.isEmpty()) {
        parseDesktopFile(desktopFile, metadata);
    }
    
    // Find executables
    QString dataDir = QString("%1/data").arg(extractDir);
    metadata.executables = findExecutables(dataDir);
    
    // Find scripts
    metadata.scripts = findScripts(extractDir);
    
    // Find icon
    if (metadata.iconPath.isEmpty()) {
        metadata.iconPath = findIcon(dataDir);
    }
    
    // Determine main executable
    if (!metadata.executables.isEmpty()) {
        // Prefer executable with same name as package
        for (const QString& exec : metadata.executables) {
            QFileInfo execInfo(exec);
            if (execInfo.baseName().toLower() == metadata.package.toLower()) {
                metadata.mainExecutable = exec;
                break;
            }
        }
        if (metadata.mainExecutable.isEmpty()) {
            metadata.mainExecutable = metadata.executables.first();
        }
    }
    
    return metadata;
}

bool RpmParser::parseSpecFile(const QString& specPath, PackageMetadata& metadata) {
    QFile file(specPath);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        return false;
    }
    
    QTextStream in(&file);
    while (!in.atEnd()) {
        QString line = in.readLine().trimmed();
        
        if (line.startsWith("Name:")) {
            metadata.package = line.mid(5).trimmed();
        } else if (line.startsWith("Version:")) {
            metadata.version = line.mid(8).trimmed();
        } else if (line.startsWith("Summary:") || line.startsWith("Description:")) {
            if (metadata.description.isEmpty()) {
                metadata.description = line.mid(line.indexOf(':') + 1).trimmed();
            }
        } else if (line.startsWith("Requires:") || line.startsWith("Requires(")) {
            QString deps = line.mid(line.indexOf(':') + 1).trimmed();
            QStringList depList = deps.split(',', Qt::SkipEmptyParts);
            for (QString& dep : depList) {
                dep = dep.trimmed();
                // Remove version constraints
                int spacePos = dep.indexOf(' ');
                if (spacePos > 0) {
                    dep = dep.left(spacePos);
                }
                if (!dep.isEmpty()) {
                    metadata.depends.append(dep);
                }
            }
        }
    }
    
    file.close();
    return true;
}

QStringList RpmParser::findExecutables(const QString& extractDir) {
    QStringList executables;
    
    QStringList searchDirs = {
        QString("%1/usr/bin").arg(extractDir),
        QString("%1/usr/sbin").arg(extractDir),
        QString("%1/opt").arg(extractDir),
        QString("%1/usr/local/bin").arg(extractDir),
        QString("%1/bin").arg(extractDir),
        QString("%1/sbin").arg(extractDir),
        QString("%1/usr/games").arg(extractDir),
        QString("%1/usr/lib").arg(extractDir),
        QString("%1/usr/libexec").arg(extractDir)
    };
    
    for (const QString& dir : searchDirs) {
        QStringList found = searchInDirectory(dir, {"*"}, true);
        executables.append(found);
    }
    
    // If no executables found with executable flag, try to find ELF binaries
    if (executables.isEmpty()) {
        for (const QString& dir : searchDirs) {
            QStringList allFiles = searchInDirectory(dir, {"*"}, false);
            for (const QString& file : allFiles) {
                if (isElfExecutable(file)) {
                    executables.append(file);
                }
            }
        }
    }
    
    // Also search for .jar files (Java applications)
    QStringList jarDirs = {
        QString("%1/usr/games").arg(extractDir),
        QString("%1/opt").arg(extractDir),
        QString("%1/usr/lib").arg(extractDir),
        QString("%1/usr/share").arg(extractDir)
    };
    
    for (const QString& dir : jarDirs) {
        QStringList jarFiles = searchInDirectory(dir, {"*.jar"}, false);
        for (const QString& jar : jarFiles) {
            if (!jar.contains("/lib/") && !jar.contains("/jre/") && !jar.contains("/man/")) {
                executables.append(jar);
            }
        }
    }
    
    // Filter out non-executable files
    QStringList filtered;
    for (const QString& exec : executables) {
        QFileInfo execInfo(exec);
        QString fileName = execInfo.fileName();
        QString filePath = exec;
        
        if (filePath.contains("/man/") || 
            filePath.contains("/doc/") || 
            filePath.contains("/share/man/") ||
            filePath.contains("/share/doc/") ||
            fileName.endsWith(".1") || 
            fileName.endsWith(".2") || 
            fileName.endsWith(".3") ||
            fileName.endsWith(".html") ||
            fileName.endsWith(".txt") ||
            fileName.endsWith(".pdf")) {
            continue;
        }
        
        if (filePath.contains("/jre/") && 
            !filePath.contains("/jre/bin/") && 
            !filePath.endsWith(".jar")) {
            continue;
        }
        
        if (execInfo.isExecutable() || 
            isElfExecutable(exec) || 
            fileName.endsWith(".jar") ||
            isScriptFile(exec)) {
            filtered.append(exec);
        }
    }
    
    return filtered;
}

QStringList RpmParser::findScripts(const QString& extractDir) {
    QStringList scripts;
    
    // RPM scripts are usually in %pre, %post, %preun, %postun sections
    // They might be extracted to /var/lib/rpm-state or similar
    // For now, we'll search common locations
    QStringList scriptDirs = {
        QString("%1/var/lib/rpm-state").arg(extractDir),
        QString("%1/etc").arg(extractDir)
    };
    
    for (const QString& dir : scriptDirs) {
        QStringList found = searchInDirectory(dir, {"*pre*", "*post*", "*un*"}, false);
        scripts.append(found);
    }
    
    return scripts;
}

QString RpmParser::findIcon(const QString& extractDir) {
    QStringList iconDirs = {
        QString("%1/usr/share/pixmaps").arg(extractDir),
        QString("%1/usr/share/icons").arg(extractDir),
        QString("%1/usr/share/icons/hicolor").arg(extractDir),
        QString("%1/usr/share/applications").arg(extractDir)
    };
    
    QStringList iconPatterns = {"*.png", "*.svg", "*.xpm", "*.ico"};
    
    for (const QString& dir : iconDirs) {
        for (const QString& pattern : iconPatterns) {
            QStringList icons = searchInDirectory(dir, {pattern}, false);
            if (!icons.isEmpty()) {
                return icons.first();
            }
        }
    }
    
    return QString();
}

QString RpmParser::findDesktopFile(const QString& extractDir) {
    QString dataDir = QString("%1/data").arg(extractDir);
    QString desktopDir = QString("%1/usr/share/applications").arg(dataDir);
    
    QDir dir(desktopDir);
    if (dir.exists()) {
        QStringList desktopFiles = dir.entryList({"*.desktop"}, QDir::Files);
        if (!desktopFiles.isEmpty()) {
            return dir.absoluteFilePath(desktopFiles.first());
        }
    }
    
    // Also check without data/ prefix (RPM structure might differ)
    desktopDir = QString("%1/usr/share/applications").arg(extractDir);
    dir.setPath(desktopDir);
    if (dir.exists()) {
        QStringList desktopFiles = dir.entryList({"*.desktop"}, QDir::Files);
        if (!desktopFiles.isEmpty()) {
            return dir.absoluteFilePath(desktopFiles.first());
        }
    }
    
    return QString();
}

QString RpmParser::parseDesktopFile(const QString& desktopPath, PackageMetadata& metadata) {
    // Same implementation as DebParser
    QFile file(desktopPath);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        return QString();
    }
    
    QTextStream in(&file);
    bool inDesktopEntry = false;
    QString execCommand;
    QString iconName;
    
    while (!in.atEnd()) {
        QString line = in.readLine().trimmed();
        
        if (line.startsWith("[Desktop Entry]")) {
            inDesktopEntry = true;
            continue;
        }
        
        if (line.startsWith("[") && !line.startsWith("[Desktop Entry]")) {
            inDesktopEntry = false;
            continue;
        }
        
        if (!inDesktopEntry) {
            continue;
        }
        
        if (line.startsWith("Exec=")) {
            execCommand = line.mid(5).trimmed();
            execCommand.remove(QRegularExpression("%[fFuUicckdDnNvm]"));
            execCommand = execCommand.trimmed();
        } else if (line.startsWith("Icon=")) {
            iconName = line.mid(5).trimmed();
        } else if (line.startsWith("Name=") && metadata.description.isEmpty()) {
            metadata.description = line.mid(5).trimmed();
        }
    }
    
    file.close();
    
    // Parse exec command similar to DebParser
    if (!execCommand.isEmpty()) {
        QString execPath = execCommand.split(' ').first();
        if (execPath.startsWith("/")) {
            QString dataDir = QString("%1/data").arg(QFileInfo(desktopPath).absolutePath().section('/', 0, -3));
            QString fullPath = QString("%1%2").arg(dataDir).arg(execPath);
            if (QFileInfo::exists(fullPath)) {
                metadata.mainExecutable = fullPath;
                metadata.executables.append(fullPath);
            }
        }
    }
    
    return QString();
}

QStringList RpmParser::searchInDirectory(const QString& dir, const QStringList& patterns, bool executableOnly) {
    QStringList results;
    QDir dirObj(dir);
    
    if (!dirObj.exists()) {
        return results;
    }
    
    for (const QString& pattern : patterns) {
        QFileInfoList entries = dirObj.entryInfoList({pattern}, QDir::Files | QDir::Executable, QDir::Name);
        
        for (const QFileInfo& info : entries) {
            if (executableOnly && !info.isExecutable()) {
                continue;
            }
            results.append(info.absoluteFilePath());
        }
    }
    
    // Recursively search subdirectories
    QFileInfoList subdirs = dirObj.entryInfoList(QDir::Dirs | QDir::NoDotAndDotDot);
    for (const QFileInfo& subdir : subdirs) {
        results.append(searchInDirectory(subdir.absoluteFilePath(), patterns, executableOnly));
    }
    
    return results;
}

bool RpmParser::isElfExecutable(const QString& filePath) {
    QFile file(filePath);
    if (!file.open(QIODevice::ReadOnly)) {
        return false;
    }
    
    QByteArray header = file.read(4);
    file.close();
    
    if (header.size() >= 4 && 
        header[0] == 0x7F && 
        header[1] == 'E' && 
        header[2] == 'L' && 
        header[3] == 'F') {
        return true;
    }
    
    if (header.size() >= 2 && header[0] == '#' && header[1] == '!') {
        return true;
    }
    
    return false;
}

bool RpmParser::isScriptFile(const QString& filePath) {
    QFile file(filePath);
    if (!file.open(QIODevice::ReadOnly)) {
        return false;
    }
    
    QByteArray header = file.read(2);
    file.close();
    
    return header.size() >= 2 && header[0] == '#' && header[1] == '!';
}

QStringList RpmParser::findJavaApplications(const QString& extractDir) {
    QStringList jarFiles;
    
    QStringList searchDirs = {
        QString("%1/usr/share").arg(extractDir),
        QString("%1/opt").arg(extractDir),
        QString("%1/usr/lib").arg(extractDir)
    };
    
    for (const QString& dir : searchDirs) {
        QStringList jars = searchInDirectory(dir, {"*.jar"}, false);
        for (const QString& jar : jars) {
            if (!jar.contains("/lib/") && !jar.contains("/jre/")) {
                jarFiles.append(jar);
            }
        }
    }
    
    return jarFiles;
}

