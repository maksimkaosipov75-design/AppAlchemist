#include "appimagebuilder.h"
#include "utils.h"
#include <QFileInfo>
#include <QStandardPaths>
#include <QDir>
#include <QDebug>
#include <QCoreApplication>

AppImageBuilder::AppImageBuilder(QObject* parent)
    : QObject(parent)
{
    m_appImageToolPath = findAppImageTool();
}

QString AppImageBuilder::findAppImageTool() {
    // Check in application directory
    QString appDir = QCoreApplication::applicationDirPath();
    QStringList searchPaths = {
        QString("%1/appimagetool").arg(appDir),
        QString("%1/thirdparty/appimagetool").arg(appDir),
        QString("%1/../thirdparty/appimagetool").arg(appDir),
        QString("%1/../../thirdparty/appimagetool").arg(appDir),  // For build directory
        "/usr/bin/appimagetool",
        "/usr/local/bin/appimagetool"
    };
    
    // Also check in project root directory (where CMakeLists.txt is)
    QDir projectRoot = QDir(QCoreApplication::applicationDirPath());
    // If we're in build directory, go up one level
    if (projectRoot.dirName() == "build") {
        projectRoot.cdUp();
    }
    searchPaths.append(projectRoot.absoluteFilePath("thirdparty/appimagetool"));
    searchPaths.append(projectRoot.absoluteFilePath("appimagetool"));
    
    // Also check in current directory
    QDir currentDir = QDir::current();
    searchPaths.append(currentDir.absoluteFilePath("appimagetool"));
    searchPaths.append(currentDir.absoluteFilePath("thirdparty/appimagetool"));
    
    qDebug() << "Searching for appimagetool in:" << searchPaths;
    
    for (const QString& path : searchPaths) {
        if (checkAppImageTool(path)) {
            qDebug() << "Found appimagetool at:" << path;
            return path;
        }
    }
    
    qWarning() << "appimagetool not found in any of the search paths";
    return QString();
}

bool AppImageBuilder::checkAppImageTool(const QString& path) {
    QFileInfo info(path);
    if (!info.exists() || !info.isExecutable()) {
        return false;
    }
    
    // Try to run it with --version
    ProcessResult result = SubprocessWrapper::execute(path, {"--version"}, {}, 5000);
    return result.success;
}

bool AppImageBuilder::buildAppImage(const QString& appDirPath, const QString& outputPath) {
    if (m_appImageToolPath.isEmpty()) {
        qWarning() << "AppImageTool not found!";
        qWarning() << "Please download appimagetool from:";
        qWarning() << "https://github.com/AppImage/AppImageKit/releases";
        qWarning() << "And place it in one of these locations:";
        qWarning() << "  - thirdparty/appimagetool (in project directory)";
        qWarning() << "  - /usr/bin/appimagetool (system-wide)";
        qWarning() << "  - /usr/local/bin/appimagetool (local)";
        return false;
    }
    
    QFileInfo appDirInfo(appDirPath);
    if (!appDirInfo.exists() || !appDirInfo.isDir()) {
        emit log(QString("ERROR: AppDir does not exist: %1").arg(appDirPath));
        return false;
    }
    
    // Check for .desktop file
    QString desktopDir = QString("%1/usr/share/applications").arg(appDirPath);
    QDir desktopDirObj(desktopDir);
    QStringList desktopFiles = desktopDirObj.entryList({"*.desktop"}, QDir::Files);
    
    if (desktopFiles.isEmpty()) {
        emit log("ERROR: No .desktop file found in AppDir/usr/share/applications/");
        emit log(QString("Checked directory: %1").arg(desktopDir));
        return false;
    }
    
    emit log(QString("Found .desktop file(s): %1").arg(desktopFiles.join(", ")));
    
    // Ensure output directory exists
    QFileInfo outputInfo(outputPath);
    QDir outputDir = outputInfo.dir();
    if (!outputDir.exists()) {
        if (!outputDir.mkpath(".")) {
            emit log(QString("ERROR: Failed to create output directory: %1").arg(outputDir.absolutePath()));
            return false;
        }
    }
    
    // Build AppImage
    emit log(QString("Running appimagetool: %1").arg(m_appImageToolPath));
    emit log(QString("AppDir: %1").arg(appDirPath));
    emit log(QString("Output: %1").arg(outputPath));
    
    // Set ARCH environment variable (required by appimagetool)
    QProcessEnvironment env = QProcessEnvironment::systemEnvironment();
    env.insert("ARCH", "x86_64");
    
    ProcessResult result = SubprocessWrapper::execute(
        m_appImageToolPath,
        {appDirPath, outputPath},
        {},
        300000,  // 5 minute timeout
        env
    );
    
    // Log output
    if (!result.stdoutOutput.isEmpty()) {
        QStringList lines = result.stdoutOutput.split('\n', Qt::SkipEmptyParts);
        for (const QString& line : lines) {
            emit log(line);
        }
    }
    
    if (!result.success) {
        emit log(QString("ERROR: AppImageTool failed with exit code: %1").arg(result.exitCode));
        emit log(QString("Error: %1").arg(result.errorMessage));
        if (!result.stderrOutput.isEmpty()) {
            QStringList errorLines = result.stderrOutput.split('\n', Qt::SkipEmptyParts);
            for (const QString& line : errorLines) {
                emit log(QString("stderr: %1").arg(line));
            }
        }
        return false;
    }
    
    emit log("AppImageTool completed successfully");
    
    // Make AppImage executable
    if (QFileInfo::exists(outputPath)) {
        SubprocessWrapper::setExecutable(outputPath);
        return true;
    }
    
    return false;
}

