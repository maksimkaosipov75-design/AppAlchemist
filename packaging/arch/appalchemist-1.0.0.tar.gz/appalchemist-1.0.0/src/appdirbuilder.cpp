#include "appdirbuilder.h"
#include "utils.h"
#include <QDir>
#include <QFileInfo>
#include <QFile>
#include <QTextStream>
#include <QDebug>
#include <QRegularExpression>

AppDirBuilder::AppDirBuilder() {
}

bool AppDirBuilder::createDirectoryStructure(const QString& appDirPath) {
    QStringList dirs = {
        QString("%1/usr/bin").arg(appDirPath),
        QString("%1/usr/lib").arg(appDirPath),
        QString("%1/usr/share/applications").arg(appDirPath),
        QString("%1/usr/share/icons/hicolor/256x256/apps").arg(appDirPath),
        QString("%1/usr/share/icons/hicolor/128x128/apps").arg(appDirPath),
        QString("%1/usr/share/icons/hicolor/64x64/apps").arg(appDirPath),
        QString("%1/usr/share/icons/hicolor/48x48/apps").arg(appDirPath),
        QString("%1/usr/share/icons/hicolor/32x32/apps").arg(appDirPath),
        QString("%1/usr/share/icons/hicolor/16x16/apps").arg(appDirPath)
    };
    
    for (const QString& dir : dirs) {
        if (!SubprocessWrapper::createDirectory(dir)) {
            return false;
        }
    }
    
    return true;
}

bool AppDirBuilder::buildAppDir(const QString& appDirPath,
                                const QString& extractedDebDir,
                                const DebMetadata& metadata,
                                const QStringList& libraries) {
    qDebug() << "Building AppDir at:" << appDirPath;
    qDebug() << "Extracted deb dir:" << extractedDebDir;
    qDebug() << "Number of executables:" << metadata.executables.size();
    if (metadata.executables.size() > 50) {
        qDebug() << "WARNING: Too many executables found, filtering will be applied";
        qDebug() << "First 10 executables:" << metadata.executables.mid(0, 10);
    }
    
    // Create directory structure
    if (!createDirectoryStructure(appDirPath)) {
        qWarning() << "Failed to create directory structure";
        return false;
    }
    
    // Copy executables
    if (!copyExecutables(appDirPath, extractedDebDir, metadata.executables)) {
        qWarning() << "Failed to copy executables";
        return false;
    }
    qDebug() << "Executables copied successfully";
    
    // Copy libraries
    if (!copyLibraries(appDirPath, libraries)) {
        qWarning() << "Failed to copy libraries";
        return false;
    }
    qDebug() << "Libraries copied successfully";
    
    // Copy resources (but skip usr/share/applications to avoid overwriting .desktop)
    if (!copyResources(appDirPath, extractedDebDir)) {
        qWarning() << "Failed to copy resources";
        return false;
    }
    qDebug() << "Resources copied successfully";
    
    // Try to copy .desktop file from extracted deb first (AFTER resources to ensure directory exists)
    QString desktopSource = QString("%1/data/usr/share/applications").arg(extractedDebDir);
    QDir desktopSourceDir(desktopSource);
    bool desktopCopied = false;
    
    qDebug() << "Looking for .desktop file in:" << desktopSource;
    
    if (desktopSourceDir.exists()) {
        QStringList desktopFiles = desktopSourceDir.entryList({"*.desktop"}, QDir::Files);
        qDebug() << "Found .desktop files in package:" << desktopFiles;
        
        if (!desktopFiles.isEmpty()) {
            QString sourceDesktop = desktopSourceDir.absoluteFilePath(desktopFiles.first());
            QString targetDesktopDir = QString("%1/usr/share/applications").arg(appDirPath);
            QDir targetDesktopDirObj(targetDesktopDir);
            if (!targetDesktopDirObj.exists()) {
                targetDesktopDirObj.mkpath(".");
            }
            QString targetDesktop = QString("%1/%2").arg(targetDesktopDir).arg(desktopFiles.first());
            
            qDebug() << "Copying .desktop from" << sourceDesktop << "to" << targetDesktop;
            
            if (SubprocessWrapper::copyFile(sourceDesktop, targetDesktop)) {
                qDebug() << "Successfully copied .desktop file:" << desktopFiles.first();
                
                // Verify and fix .desktop file (ensure Categories= is present)
                if (QFileInfo::exists(targetDesktop)) {
                    qDebug() << "Verified .desktop file exists at:" << targetDesktop;
                    if (!fixDesktopFile(targetDesktop)) {
                        qWarning() << "Failed to fix .desktop file, will create new one";
                        QFile::remove(targetDesktop);
                        desktopCopied = false;
                    } else {
                        desktopCopied = true;
                    }
                } else {
                    qWarning() << "WARNING: .desktop file was copied but doesn't exist at:" << targetDesktop;
                    desktopCopied = false;
                }
            } else {
                qWarning() << "Failed to copy .desktop file from package";
            }
        }
    } else {
        qDebug() << "Desktop source directory does not exist:" << desktopSource;
    }
    
    // Create .desktop file if not copied from package
    if (!desktopCopied) {
        qDebug() << "Creating new .desktop file";
        if (!createDesktopFile(appDirPath, metadata)) {
            qWarning() << "Failed to create desktop file";
            return false;
        }
        qDebug() << "Desktop file created successfully";
    } else {
        qDebug() << "Desktop file copied from package";
    }
    
    // Final verification - list all .desktop files
    QString finalDesktopDir = QString("%1/usr/share/applications").arg(appDirPath);
    QDir finalDesktopDirObj(finalDesktopDir);
    if (finalDesktopDirObj.exists()) {
        QStringList finalDesktopFiles = finalDesktopDirObj.entryList({"*.desktop"}, QDir::Files);
        qDebug() << "Final .desktop files in AppDir:" << finalDesktopFiles;
        for (const QString& file : finalDesktopFiles) {
            QString fullPath = finalDesktopDirObj.absoluteFilePath(file);
            qDebug() << "  -" << fullPath << "(exists:" << QFileInfo::exists(fullPath) << ")";
            
            // CRITICAL: appimagetool requires .desktop file in AppDir root!
            // Copy .desktop file to AppDir root
            QString rootDesktopPath = QString("%1/%2").arg(appDirPath).arg(file);
            if (SubprocessWrapper::copyFile(fullPath, rootDesktopPath)) {
                qDebug() << "Copied .desktop file to AppDir root:" << rootDesktopPath;
                
                // Also ensure icon path in root .desktop file points to root icon
                // Read and fix icon path in root .desktop
                QFile rootDesktopFile(rootDesktopPath);
                if (rootDesktopFile.open(QIODevice::ReadWrite | QIODevice::Text)) {
                    QString content = rootDesktopFile.readAll();
                    rootDesktopFile.close();
                    
                    // Fix Icon= path to point to root icon (without path, just name)
                    QRegularExpression iconRegex("(?i)^Icon=(.+)$", QRegularExpression::MultilineOption);
                    QRegularExpressionMatch match = iconRegex.match(content);
                    if (match.hasMatch()) {
                        QString iconValue = match.captured(1).trimmed();
                        // Remove path, keep only name
                        QString iconName = QFileInfo(iconValue).baseName();
                        if (!iconName.isEmpty()) {
                            content.replace(iconRegex, QString("Icon=%1").arg(iconName));
                            
                            if (rootDesktopFile.open(QIODevice::WriteOnly | QIODevice::Text | QIODevice::Truncate)) {
                                QTextStream out(&rootDesktopFile);
                                out << content;
                                rootDesktopFile.close();
                            }
                            qDebug() << "Fixed Icon= path in root .desktop file:" << iconName;
                        }
                    }
                }
            } else {
                qWarning() << "Failed to copy .desktop file to AppDir root:" << rootDesktopPath;
            }
        }
    } else {
        qWarning() << "ERROR: Desktop directory does not exist:" << finalDesktopDir;
    }
    
    // Determine icon name from .desktop file first
    QString iconNameFromDesktop;
    if (finalDesktopDirObj.exists()) {
        QStringList finalDesktopFiles = finalDesktopDirObj.entryList({"*.desktop"}, QDir::Files);
        if (!finalDesktopFiles.isEmpty()) {
            QString desktopPath = finalDesktopDirObj.absoluteFilePath(finalDesktopFiles.first());
            QFile desktopFile(desktopPath);
            if (desktopFile.open(QIODevice::ReadOnly | QIODevice::Text)) {
                QTextStream in(&desktopFile);
                while (!in.atEnd()) {
                    QString line = in.readLine().trimmed();
                    if (line.startsWith("Icon=", Qt::CaseInsensitive)) {
                        iconNameFromDesktop = line.mid(5).trimmed();
                        // Remove path, keep only name
                        iconNameFromDesktop = QFileInfo(iconNameFromDesktop).baseName();
                        qDebug() << "Found Icon= in .desktop file:" << iconNameFromDesktop;
                        break;
                    }
                }
                desktopFile.close();
            }
        }
    }
    
    // Copy icon (CRITICAL: appimagetool requires icon in AppDir root)
    QString rootIconName;
    QString iconNameToUse = iconNameFromDesktop.isEmpty() ? metadata.package : iconNameFromDesktop;
    
    if (!metadata.iconPath.isEmpty()) {
        if (!copyIcon(appDirPath, metadata.iconPath, metadata)) {
            qWarning() << "Failed to copy icon, continuing anyway";
        }
        
        // Also copy icon to AppDir root (required by appimagetool)
        QFileInfo iconInfo(metadata.iconPath);
        QString iconExt = iconInfo.suffix();
        if (iconExt.isEmpty()) {
            // Try to determine extension from file name
            QString fileName = iconInfo.fileName();
            int lastDot = fileName.lastIndexOf('.');
            if (lastDot > 0) {
                iconExt = fileName.mid(lastDot + 1);
            } else {
                iconExt = "png"; // Default
            }
        }
        
        // Try different icon names: from desktop, then package name
        QStringList iconNamesToTry = {iconNameToUse, metadata.package};
        bool iconCopied = false;
        
        for (const QString& name : iconNamesToTry) {
            rootIconName = QString("%1.%2").arg(name).arg(iconExt);
            QString rootIconPath = QString("%1/%2").arg(appDirPath).arg(rootIconName);
            
            if (SubprocessWrapper::copyFile(metadata.iconPath, rootIconPath)) {
                qDebug() << "Copied icon to AppDir root:" << rootIconPath;
                iconCopied = true;
                break;
            }
        }
        
        if (!iconCopied) {
            qWarning() << "Failed to copy icon to AppDir root";
            rootIconName.clear();
        }
    } else {
        // Try to find icon in standard locations
        QStringList iconSearchPaths = {
            QString("%1/data/usr/share/pixmaps").arg(extractedDebDir),
            QString("%1/data/usr/share/icons/hicolor/256x256/apps").arg(extractedDebDir),
            QString("%1/data/usr/share/icons/hicolor/128x128/apps").arg(extractedDebDir),
            QString("%1/data/usr/share/icons/hicolor/64x64/apps").arg(extractedDebDir),
            QString("%1/data/usr/share/icons/hicolor/48x48/apps").arg(extractedDebDir),
            QString("%1/data/usr/share/icons/hicolor/32x32/apps").arg(extractedDebDir),
            QString("%1/data/usr/share/icons/hicolor/16x16/apps").arg(extractedDebDir),
            QString("%1/data/usr/share/icons").arg(extractedDebDir),
            QString("%1/data/opt").arg(extractedDebDir)
        };
        
        QStringList iconExtensions = {"png", "svg", "xpm", "ico"};
        bool iconFound = false;
        
        qDebug() << "Searching for icon with name:" << iconNameToUse;
        
        // First, try to find icon with exact name
        for (const QString& searchPath : iconSearchPaths) {
            QDir searchDir(searchPath);
            if (searchDir.exists()) {
                qDebug() << "Searching in:" << searchPath;
                for (const QString& ext : iconExtensions) {
                    // Try exact name match first
                    QString exactName = QString("%1.%2").arg(iconNameToUse).arg(ext);
                    QString exactPath = searchDir.absoluteFilePath(exactName);
                    if (QFileInfo::exists(exactPath)) {
                        QFileInfo foundIconInfo(exactPath);
                        QString iconExt = foundIconInfo.suffix();
                        
                        // Copy to AppDir root with correct name
                        rootIconName = QString("%1.%2").arg(iconNameToUse).arg(iconExt);
                        QString rootIconPath = QString("%1/%2").arg(appDirPath).arg(rootIconName);
                        
                        if (SubprocessWrapper::copyFile(exactPath, rootIconPath)) {
                            qDebug() << "Found and copied icon (exact match):" << rootIconPath;
                            iconFound = true;
                            break;
                        }
                    }
                    
                    // Also try wildcard search
                    QStringList iconFiles = searchDir.entryList({QString("*.%1").arg(ext)}, QDir::Files);
                    for (const QString& iconFile : iconFiles) {
                        // Check if filename contains icon name
                        if (iconFile.contains(iconNameToUse, Qt::CaseInsensitive)) {
                            QString foundIcon = searchDir.absoluteFilePath(iconFile);
                            QFileInfo foundIconInfo(foundIcon);
                            QString iconExt = foundIconInfo.suffix();
                            
                            // Copy to AppDir root with correct name
                            rootIconName = QString("%1.%2").arg(iconNameToUse).arg(iconExt);
                            QString rootIconPath = QString("%1/%2").arg(appDirPath).arg(rootIconName);
                            
                            if (SubprocessWrapper::copyFile(foundIcon, rootIconPath)) {
                                qDebug() << "Found and copied icon (partial match):" << rootIconPath << "from" << foundIcon;
                                iconFound = true;
                                break;
                            }
                        }
                    }
                    if (iconFound) break;
                }
                if (iconFound) break;
            }
        }
        
        // If still not found, try to find any icon file and use it
        if (!iconFound) {
            qDebug() << "Exact match not found, searching for any icon file";
            for (const QString& searchPath : iconSearchPaths) {
                QDir searchDir(searchPath);
                if (searchDir.exists()) {
                    for (const QString& ext : iconExtensions) {
                        QStringList iconFiles = searchDir.entryList({QString("*.%1").arg(ext)}, QDir::Files);
                        if (!iconFiles.isEmpty()) {
                            QString foundIcon = searchDir.absoluteFilePath(iconFiles.first());
                            QFileInfo foundIconInfo(foundIcon);
                            QString iconExt = foundIconInfo.suffix();
                            
                            // Copy to AppDir root with correct name
                            rootIconName = QString("%1.%2").arg(iconNameToUse).arg(iconExt);
                            QString rootIconPath = QString("%1/%2").arg(appDirPath).arg(rootIconName);
                            
                            if (SubprocessWrapper::copyFile(foundIcon, rootIconPath)) {
                                qDebug() << "Found and copied any available icon:" << rootIconPath << "from" << foundIcon;
                                iconFound = true;
                                break;
                            }
                        }
                    }
                    if (iconFound) break;
                }
            }
        }
        
        if (!iconFound) {
            qWarning() << "WARNING: No icon found for" << iconNameToUse;
            qWarning() << "Searched in:" << iconSearchPaths;
            qWarning() << "Creating a placeholder icon to satisfy appimagetool requirements";
            
            // Create a minimal 1x1 PNG as placeholder
            // This is a minimal valid PNG file (1x1 transparent pixel)
            QByteArray placeholderPng = QByteArray::fromBase64(
                "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg=="
            );
            
            rootIconName = QString("%1.png").arg(iconNameToUse);
            QString rootIconPath = QString("%1/%2").arg(appDirPath).arg(rootIconName);
            
            QFile placeholderFile(rootIconPath);
            if (placeholderFile.open(QIODevice::WriteOnly)) {
                placeholderFile.write(placeholderPng);
                placeholderFile.close();
                qDebug() << "Created placeholder icon:" << rootIconPath;
                iconFound = true;
            } else {
                qWarning() << "Failed to create placeholder icon:" << rootIconPath;
            }
        }
    }
    
    // Update .desktop file to use correct icon name (if we have one)
    if (!rootIconName.isEmpty() && finalDesktopDirObj.exists()) {
        QStringList finalDesktopFiles = finalDesktopDirObj.entryList({"*.desktop"}, QDir::Files);
        for (const QString& file : finalDesktopFiles) {
            QString desktopPath = finalDesktopDirObj.absoluteFilePath(file);
            QString rootDesktopPath = QString("%1/%2").arg(appDirPath).arg(file);
            
            // Update Icon= in both .desktop files
            for (const QString& path : {desktopPath, rootDesktopPath}) {
                if (QFileInfo::exists(path)) {
                    QFile desktopFile(path);
                    if (desktopFile.open(QIODevice::ReadWrite | QIODevice::Text)) {
                        QString content = desktopFile.readAll();
                        desktopFile.close();
                        
                        // Replace Icon= with just the icon name (no path, no extension in Icon=)
                        QString iconNameOnly = QFileInfo(rootIconName).baseName();
                        QRegularExpression iconRegex("(?i)^Icon=(.+)$", QRegularExpression::MultilineOption);
                        content.replace(iconRegex, QString("Icon=%1").arg(iconNameOnly));
                        
                        if (desktopFile.open(QIODevice::WriteOnly | QIODevice::Text | QIODevice::Truncate)) {
                            QTextStream out(&desktopFile);
                            out << content;
                            desktopFile.close();
                            qDebug() << "Updated Icon= in .desktop file:" << path << "to" << iconNameOnly;
                        }
                    }
                }
            }
        }
    }
    
    // Create AppRun
    if (!createAppRun(appDirPath, metadata)) {
        qWarning() << "Failed to create AppRun";
        return false;
    }
    qDebug() << "AppRun created successfully";
    
    // Create symlink to main executable (skip for jar files, they're handled by AppRun)
    if (!metadata.mainExecutable.isEmpty()) {
        QFileInfo execInfo(metadata.mainExecutable);
        QString execName = execInfo.fileName();
        
        // Don't create symlink for jar files
        if (!execName.endsWith(".jar")) {
            QString symlinkPath = QString("%1/%2").arg(appDirPath).arg(execName);
            QString targetPath;
            
            // Determine correct target path based on where executable was placed
            if (metadata.mainExecutable.contains("/usr/games/")) {
                targetPath = QString("usr/games/%1").arg(execName);
            } else if (metadata.mainExecutable.contains("/opt/")) {
                targetPath = QString("opt/%1").arg(execName);
            } else {
                targetPath = QString("usr/bin/%1").arg(execName);
            }
            
            QFile::remove(symlinkPath);
            if (!QFile::link(targetPath, symlinkPath)) {
                // Fallback: copy instead of symlink
                QString sourcePath = QString("%1/%2").arg(appDirPath).arg(targetPath);
                if (QFileInfo::exists(sourcePath)) {
                    SubprocessWrapper::copyFile(sourcePath, symlinkPath);
                    SubprocessWrapper::setExecutable(symlinkPath);
                }
            }
        }
    }
    
    return true;
}

bool AppDirBuilder::copyExecutables(const QString& appDirPath,
                                    const QString& extractedDebDir,
                                    const QStringList& executables) {
    qDebug() << "Copying" << executables.size() << "executables";
    
    int copied = 0;
    int failed = 0;
    
    for (const QString& exec : executables) {
        QFileInfo execInfo(exec);
        if (!execInfo.exists()) {
            qWarning() << "Executable does not exist:" << exec;
            failed++;
            continue;
        }
        
        qDebug() << "Copying executable:" << exec;
        
        QString relativePath = exec;
        
        // Remove extractDir prefix (may be /extracted or /extracted/data)
        if (relativePath.startsWith(extractedDebDir)) {
            relativePath = relativePath.mid(extractedDebDir.length());
            if (relativePath.startsWith("/")) {
                relativePath = relativePath.mid(1);
            }
            // Remove "data/" prefix if present
            if (relativePath.startsWith("data/")) {
                relativePath = relativePath.mid(5);
            }
        } else if (relativePath.contains("/data/")) {
            // Extract path after /data/
            int dataPos = relativePath.indexOf("/data/");
            relativePath = relativePath.mid(dataPos + 6);
        }
        
        // Map to AppDir structure - preserve original directory structure
        QString targetPath;
        if (relativePath.startsWith("usr/bin/") || relativePath.startsWith("usr/sbin/")) {
            targetPath = QString("%1/%2").arg(appDirPath).arg(relativePath);
        } else if (relativePath.startsWith("usr/games/")) {
            targetPath = QString("%1/%2").arg(appDirPath).arg(relativePath);
        } else if (relativePath.startsWith("opt/")) {
            // Preserve opt/ structure (important for Chrome, Steam, etc.)
            targetPath = QString("%1/%2").arg(appDirPath).arg(relativePath);
        } else if (relativePath.startsWith("usr/lib/")) {
            targetPath = QString("%1/%2").arg(appDirPath).arg(relativePath);
        } else {
            // Put in usr/bin (or usr/games for jar files)
            if (execInfo.suffix().toLower() == "jar") {
                targetPath = QString("%1/usr/games/%2").arg(appDirPath).arg(execInfo.fileName());
            } else {
                targetPath = QString("%1/usr/bin/%2").arg(appDirPath).arg(execInfo.fileName());
            }
        }
        
        // Create target directory if needed
        QFileInfo targetInfo(targetPath);
        QDir targetDir = targetInfo.dir();
        if (!targetDir.exists()) {
            if (!targetDir.mkpath(".")) {
                qWarning() << "Failed to create directory:" << targetDir.absolutePath();
                return false;
            }
        }
        
        // Check if it's a shell script that needs path modification
        QString execName = execInfo.fileName();
        bool isShellScript = execInfo.suffix().toLower() == "sh" || 
                             execName.contains("yandex") || 
                             execName.contains("music");
        
        if (isShellScript) {
            // Read script, modify paths, write to target
            QFile sourceFile(exec);
            if (!sourceFile.open(QIODevice::ReadOnly | QIODevice::Text)) {
                qWarning() << "Failed to open script for reading:" << exec;
                failed++;
                continue;
            }
            
            QString content = sourceFile.readAll();
            sourceFile.close();
            
            // Replace absolute paths with relative ones for AppImage
            // IMPORTANT: Replace more specific paths first to avoid double replacement
            // First, replace yandex-music specific paths (most specific)
            content.replace("/usr/lib/yandex-music/electron/electron", "${HERE}/usr/lib/yandex-music/electron/electron");
            content.replace("/usr/lib/yandex-music/default.conf", "${HERE}/usr/lib/yandex-music/default.conf");
            content.replace("/usr/lib/yandex-music/yandex-music.asar", "${HERE}/usr/lib/yandex-music/yandex-music.asar");
            // Then replace general yandex-music paths
            content.replace("/usr/lib/yandex-music/", "${HERE}/usr/lib/yandex-music/");
            // Replace ELECTRON_BIN variable (must use already replaced path)
            content.replace("ELECTRON_BIN=${ELECTRON_CUSTOM_BIN:-/usr/lib/yandex-music/electron/electron}",
                           "ELECTRON_BIN=${ELECTRON_CUSTOM_BIN:-${HERE}/usr/lib/yandex-music/electron/electron}");
            content.replace("cp /usr/lib/yandex-music/default.conf",
                           "cp \"${HERE}/usr/lib/yandex-music/default.conf\"");
            // Replace general /usr/lib/ paths (but only if not already containing ${HERE})
            // Use a more careful approach - only replace standalone /usr/lib/ that's not part of ${HERE}/usr/lib/
            content.replace(QRegularExpression(R"((?<!\$\{HERE\})/usr/lib/(?!yandex-music))"), "${HERE}/usr/lib/");
            
            QFile targetFile(targetPath);
            if (!targetFile.open(QIODevice::WriteOnly | QIODevice::Text | QIODevice::Truncate)) {
                qWarning() << "Failed to open script for writing:" << targetPath;
                failed++;
                continue;
            }
            
            QTextStream out(&targetFile);
            out << content;
            targetFile.close();
        } else {
            // Regular file copy
            if (!SubprocessWrapper::copyFile(exec, targetPath)) {
                qWarning() << "Failed to copy executable from" << exec << "to" << targetPath;
                failed++;
                // Don't fail completely, continue with other files
                continue;
            }
        }
        
        copied++;
        
        // Set executable only for non-jar files
        if (!execInfo.suffix().toLower().endsWith("jar")) {
            if (!SubprocessWrapper::setExecutable(targetPath)) {
                qWarning() << "Failed to set executable permissions:" << targetPath;
            }
        }
    }
    
    qDebug() << "Copied" << copied << "executables," << failed << "failed";
    
    // Return true if at least some executables were copied
    return copied > 0;
}

bool AppDirBuilder::copyLibraries(const QString& appDirPath, const QStringList& libraries) {
    for (const QString& lib : libraries) {
        QFileInfo libInfo(lib);
        if (!libInfo.exists()) {
            qWarning() << "Library does not exist:" << lib;
            continue;
        }
        
        QString libName = libInfo.fileName();
        QString libPath = lib;
        
        // Determine target path - preserve directory structure for opt/ libraries
        QString targetPath;
        if (libPath.contains("/opt/google/chrome/")) {
            // Preserve opt/google/chrome structure
            int optPos = libPath.indexOf("/opt/");
            QString afterOpt = libPath.mid(optPos + 1);
            targetPath = QString("%1/%2").arg(appDirPath).arg(afterOpt);
        } else if (libPath.contains("/opt/")) {
            // Preserve other opt/ structures
            int optPos = libPath.indexOf("/opt/");
            QString afterOpt = libPath.mid(optPos + 1);
            if (afterOpt.contains("/data/")) {
                afterOpt = afterOpt.section("/data/", 1);
            }
            targetPath = QString("%1/%2").arg(appDirPath).arg(afterOpt);
        } else {
            // Standard library location
            targetPath = QString("%1/usr/lib/%2").arg(appDirPath).arg(libName);
        }
        
        // Create target directory if needed
        QFileInfo targetInfo(targetPath);
        QDir targetDir = targetInfo.dir();
        if (!targetDir.exists()) {
            targetDir.mkpath(".");
        }
        
        if (!SubprocessWrapper::copyFile(lib, targetPath)) {
            qWarning() << "Failed to copy library:" << lib << "to" << targetPath;
            continue;
        }
    }
    
    return true;
}

bool AppDirBuilder::copyResources(const QString& appDirPath, const QString& extractedDebDir) {
    QStringList resourceDirs = {
        "usr/lib",
        "usr/games",  // Important for Java apps with bundled JRE
        "opt"
    };
    
    // Copy usr/share but exclude applications directory (we'll handle .desktop separately)
    QString shareSource = QString("%1/data/usr/share").arg(extractedDebDir);
    QString shareTarget = QString("%1/usr/share").arg(appDirPath);
    
    if (QDir(shareSource).exists()) {
        QDir shareTargetDir(shareTarget);
        if (!shareTargetDir.exists()) {
            shareTargetDir.mkpath(".");
        }
        
        // Copy usr/share subdirectories except applications
        QDir shareSourceDir(shareSource);
        QStringList shareSubdirs = shareSourceDir.entryList(QDir::Dirs | QDir::NoDotAndDotDot);
        for (const QString& subdir : shareSubdirs) {
            if (subdir == "applications") {
                // Skip applications, we'll handle .desktop separately
                continue;
            }
            QString srcPath = shareSourceDir.absoluteFilePath(subdir);
            QString destPath = shareTargetDir.absoluteFilePath(subdir);
            
            QDir destDir(destPath);
            if (!destDir.exists()) {
                destDir.mkpath(".");
            }
            
            if (!SubprocessWrapper::copyDirectory(srcPath, destPath)) {
                qWarning() << "Failed to copy share resource:" << srcPath;
            }
        }
    }
    
    // Copy other resource directories
    for (const QString& resourceDir : resourceDirs) {
        QString sourcePath = QString("%1/data/%2").arg(extractedDebDir).arg(resourceDir);
        QString targetPath = QString("%1/%2").arg(appDirPath).arg(resourceDir);
        
        if (QDir(sourcePath).exists()) {
            // Create target directory
            QDir targetDir(targetPath);
            if (!targetDir.exists()) {
                targetDir.mkpath(".");
            }
            
            if (!SubprocessWrapper::copyDirectory(sourcePath, targetPath)) {
                qWarning() << "Failed to copy resources from:" << sourcePath << "to" << targetPath;
                // Don't fail completely, just warn
            }
        }
    }
    
    return true;
}

bool AppDirBuilder::createDesktopFile(const QString& appDirPath, const DebMetadata& metadata) {
    QString desktopDir = QString("%1/usr/share/applications").arg(appDirPath);
    QDir dir(desktopDir);
    if (!dir.exists()) {
        dir.mkpath(".");
    }
    
    QString desktopPath = QString("%1/%2.desktop")
        .arg(desktopDir)
        .arg(metadata.package);
    
    qDebug() << "Creating .desktop file at:" << desktopPath;
    
    QFile file(desktopPath);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        qWarning() << "Failed to open .desktop file for writing:" << desktopPath;
        return false;
    }
    
    QTextStream out(&file);
    out << "[Desktop Entry]\n";
    out << "Type=Application\n";
    out << "Name=" << metadata.package << "\n";
    
    if (!metadata.description.isEmpty()) {
        // Take first line of description
        QString desc = metadata.description.split('\n').first();
        // Escape special characters
        desc.replace("&", "&amp;");
        out << "Comment=" << desc << "\n";
    }
    
    // Determine Exec path
    QString execPath;
    if (!metadata.mainExecutable.isEmpty()) {
        QFileInfo execInfo(metadata.mainExecutable);
        QString execName = execInfo.fileName();
        // Check if it's a jar file
        if (execName.endsWith(".jar")) {
            execPath = execName;
        } else {
            // Determine relative path
            if (metadata.mainExecutable.contains("/usr/games/")) {
                execPath = QString("usr/games/%1").arg(execName);
            } else {
                execPath = QString("usr/bin/%1").arg(execName);
            }
        }
    } else if (!metadata.executables.isEmpty()) {
        QFileInfo execInfo(metadata.executables.first());
        QString execName = execInfo.fileName();
        if (execName.endsWith(".jar")) {
            execPath = execName;
        } else {
            execPath = QString("usr/bin/%1").arg(execName);
        }
    }
    
    if (!execPath.isEmpty()) {
        out << "Exec=" << execPath << "\n";
    }
    
    out << "Icon=" << metadata.package << "\n";
    
    // Categories is REQUIRED by appimagetool
    out << "Categories=Utility;\n";
    
    out << "Terminal=false\n";
    
    file.close();
    
    // Verify file was created
    if (!QFileInfo::exists(desktopPath)) {
        qWarning() << ".desktop file was not created:" << desktopPath;
        return false;
    }
    
    qDebug() << ".desktop file created successfully:" << desktopPath;
    return true;
}

bool AppDirBuilder::fixDesktopFile(const QString& desktopPath) {
    QFile file(desktopPath);
    if (!file.open(QIODevice::ReadWrite | QIODevice::Text)) {
        qWarning() << "Failed to open .desktop file for fixing:" << desktopPath;
        return false;
    }
    
    QTextStream in(&file);
    QString content = in.readAll();
    file.close();
    
    bool hasCategories = content.contains("Categories=", Qt::CaseInsensitive);
    bool modified = false;
    
    if (!hasCategories) {
        qDebug() << "Adding missing Categories= to .desktop file";
        // Find the last line before [Desktop Entry] section ends or before another section
        // Add Categories= before Terminal= if present, or at the end
        if (content.contains("Terminal=", Qt::CaseInsensitive)) {
            content.replace(QRegularExpression("(?i)(Terminal=.*)"), "Categories=Utility;\n\\1");
        } else {
            // Add at the end of [Desktop Entry] section
            if (content.contains("[Desktop Entry]", Qt::CaseInsensitive)) {
                // Find end of Desktop Entry section or end of file
                int entryEnd = content.indexOf("\n[", content.indexOf("[Desktop Entry]"));
                if (entryEnd == -1) {
                    entryEnd = content.length();
                }
                content.insert(entryEnd, "Categories=Utility;\n");
            } else {
                // No Desktop Entry section, add at end
                content += "\nCategories=Utility;\n";
            }
        }
        modified = true;
    }
    
    // Also ensure Type=Application is present
    if (!content.contains("Type=Application", Qt::CaseInsensitive) && 
        content.contains("[Desktop Entry]", Qt::CaseInsensitive)) {
        qDebug() << "Adding missing Type=Application to .desktop file";
        content.replace(QRegularExpression("(?i)(\\[Desktop Entry\\])"), "\\1\nType=Application");
        modified = true;
    }
    
    if (modified) {
        if (!file.open(QIODevice::WriteOnly | QIODevice::Text | QIODevice::Truncate)) {
            qWarning() << "Failed to write fixed .desktop file:" << desktopPath;
            return false;
        }
        QTextStream out(&file);
        out << content;
        file.close();
        qDebug() << "Fixed .desktop file:" << desktopPath;
    }
    
    return true;
}

bool AppDirBuilder::copyIcon(const QString& appDirPath, const QString& iconPath, const DebMetadata& metadata) {
    QFileInfo iconInfo(iconPath);
    QString iconExt = iconInfo.suffix();
    QString iconName = QString("%1.%2").arg(metadata.package).arg(iconExt);
    
    // Copy to all icon sizes
    QStringList iconSizes = {"256x256", "128x128", "64x64", "48x48", "32x32", "16x16"};
    
    for (const QString& size : iconSizes) {
        QString targetPath = QString("%1/usr/share/icons/hicolor/%2/apps/%3")
            .arg(appDirPath)
            .arg(size)
            .arg(iconName);
        
        SubprocessWrapper::copyFile(iconPath, targetPath);
    }
    
    return true;
}

bool AppDirBuilder::createAppRun(const QString& appDirPath, const DebMetadata& metadata) {
    QString appRunPath = QString("%1/AppRun").arg(appDirPath);
    
    QFile file(appRunPath);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        return false;
    }
    
    QTextStream out(&file);
    out << "#!/bin/bash\n";
    out << "HERE=\"$(dirname \"$(readlink -f \"${0}\")\")\"\n";
    out << "\n";
    out << "# Set up environment\n";
    out << "export PATH=\"${HERE}/usr/bin:${HERE}/usr/sbin:${HERE}/usr/games:${HERE}/opt/google/chrome:${HERE}/opt/steam:${HERE}/opt:${PATH}\"\n";
    out << "\n";
    out << "# Set library paths (order matters - bundled libs first)\n";
    out << "# Include all opt/ subdirectories for Electron apps\n";
    out << "export LD_LIBRARY_PATH=\"${HERE}/opt/google/chrome:${HERE}/opt/steam:${HERE}/opt:${HERE}/usr/lib:${HERE}/usr/lib/x86_64-linux-gnu:${LD_LIBRARY_PATH}\"\n";
    out << "\n";
    out << "# Set XDG directories\n";
    out << "export XDG_DATA_DIRS=\"${HERE}/usr/share:${XDG_DATA_DIRS}\"\n";
    out << "export XDG_CONFIG_DIRS=\"${HERE}/etc/xdg:${XDG_CONFIG_DIRS}\"\n";
    out << "\n";
    out << "# Chrome-specific environment variables\n";
    out << "export CHROME_DEVEL_SANDBOX=\"${HERE}/opt/google/chrome/chrome-sandbox\"\n";
    out << "\n";
    
    if (!metadata.mainExecutable.isEmpty()) {
        QFileInfo execInfo(metadata.mainExecutable);
        QString execName = execInfo.fileName();
        QString execPath = execInfo.absoluteFilePath();
        
        // Check if it's a Java application (.jar file)
        if (execName.endsWith(".jar")) {
            // Find Java in the bundled JRE or use system Java
            // Try common JRE locations
            out << "JAVA=\"\"\n";
            out << "for jre_path in \"${HERE}/usr/games\"/*/lib/jvm/jre/bin/java \"${HERE}/usr/lib\"/*/jre/bin/java \"${HERE}/opt\"/*/jre/bin/java; do\n";
            out << "    if [ -f \"$jre_path\" ]; then\n";
            out << "        JAVA=\"$jre_path\"\n";
            out << "        break\n";
            out << "    fi\n";
            out << "done\n";
            out << "if [ -z \"$JAVA\" ]; then\n";
            out << "    JAVA=\"java\"\n";
            out << "fi\n";
            // Determine jar location
            QString jarDir = "usr/games";
            if (execPath.contains("/usr/games/")) {
                jarDir = "usr/games";
            } else if (execPath.contains("/opt/")) {
                jarDir = "opt";
            } else if (execPath.contains("/usr/lib/")) {
                jarDir = "usr/lib";
            }
            QString jarRelativePath = execPath;
            if (jarRelativePath.contains("/data/")) {
                jarRelativePath = jarRelativePath.section("/data/", 1);
            }
            out << "exec \"$JAVA\" -jar \"${HERE}/" << jarRelativePath << "\" \"$@\"\n";
        } else {
            // Regular executable - determine correct path
            QString relativePath;
            if (execPath.contains("/opt/google/chrome/")) {
                relativePath = "opt/google/chrome/" + execName;
            } else if (execPath.contains("/opt/steam/")) {
                relativePath = "opt/steam/" + execName;
            } else if (execPath.contains("/opt/")) {
                // Extract opt path
                int optPos = execPath.indexOf("/opt/");
                if (optPos >= 0) {
                    QString afterOpt = execPath.mid(optPos + 1);
                    if (afterOpt.contains("/data/")) {
                        afterOpt = afterOpt.section("/data/", 1);
                    }
                    relativePath = afterOpt;
                } else {
                    relativePath = QString("usr/bin/%1").arg(execName);
                }
            } else if (execPath.contains("/usr/bin/")) {
                relativePath = QString("usr/bin/%1").arg(execName);
            } else if (execPath.contains("/usr/sbin/")) {
                relativePath = QString("usr/sbin/%1").arg(execName);
            } else if (execPath.contains("/usr/games/")) {
                relativePath = QString("usr/games/%1").arg(execName);
            } else {
                relativePath = QString("usr/bin/%1").arg(execName);
            }
            
            // Check if it's a shell script that might need special handling
            bool isScript = execName.endsWith(".sh") || 
                           (execPath.contains("/usr/bin/") && execName.contains("yandex")) ||
                           (execPath.contains("/usr/bin/") && execName.contains("music"));
            
            // For Chrome, use wrapper script
            if (execName == "chrome" && relativePath.contains("opt/google/chrome")) {
                out << "# Chrome wrapper - set up sandbox and run from correct directory\n";
                out << "# Note: chrome-sandbox requires setuid, which may not work in AppImage\n";
                out << "# Chrome will fall back to --no-sandbox mode if needed\n";
                out << "if [ -f \"${HERE}/opt/google/chrome/chrome-sandbox\" ]; then\n";
                out << "    # Try to set setuid bit (may fail in AppImage, that's OK)\n";
                out << "    chmod 4755 \"${HERE}/opt/google/chrome/chrome-sandbox\" 2>/dev/null || true\n";
                out << "fi\n";
                out << "cd \"${HERE}/opt/google/chrome\"\n";
                out << "# Run Chrome - it will handle sandbox issues automatically\n";
                out << "exec \"${HERE}/" << relativePath << "\" \"$@\"\n";
            } else if ((execName.contains("yandex") && execName.contains("music")) || 
                       (relativePath.contains("/usr/bin/") && execName.contains("yandex"))) {
                // For Yandex Music, directly launch Electron instead of using the wrapper script
                // This avoids issues with path replacement in the script
                out << "# Yandex Music - launch Electron directly\n";
                out << "CONFIG_HOME=\"${XDG_CONFIG_HOME:-$HOME/.config}\"\n";
                out << "CONFIG_FILE=\"${YANDEX_MUSIC_CONFIG:-$CONFIG_HOME/yandex-music.conf}\"\n";
                out << "\n";
                out << "# Copy default config if needed\n";
                out << "if [ ! -f \"$CONFIG_FILE\" ]; then\n";
                out << "    mkdir -p \"$(dirname \"$CONFIG_FILE\")\"\n";
                out << "    if [ -f \"${HERE}/usr/lib/yandex-music/default.conf\" ]; then\n";
                out << "        cp \"${HERE}/usr/lib/yandex-music/default.conf\" \"$CONFIG_FILE\"\n";
                out << "    fi\n";
                out << "fi\n";
                out << "\n";
                out << "# Set Wayland flags if needed\n";
                out << "WAYLAND_FLAGS=\"\"\n";
                out << "if [ \"$XDG_SESSION_TYPE\" == \"wayland\" ]; then\n";
                out << "    WAYLAND_FLAGS=\"--ozone-platform=wayland\"\n";
                out << "fi\n";
                out << "\n";
                out << "# Set environment variables\n";
                out << "export TRAY_ENABLED=${TRAY_ENABLED:-0}\n";
                out << "export ALWAYS_LEAVE_TO_TRAY=${ALWAYS_LEAVE_TO_TRAY:-0}\n";
                out << "export DEV_TOOLS=${DEV_TOOLS:-0}\n";
                out << "export CUSTOM_TITLE_BAR=${CUSTOM_TITLE_BAR:-0}\n";
                out << "export VIBE_ANIMATION_MAX_FPS=${VIBE_ANIMATION_MAX_FPS:-25}\n";
                out << "\n";
                out << "# Launch Electron directly\n";
                out << "exec \"${HERE}/usr/lib/yandex-music/electron/electron\" \"${HERE}/usr/lib/yandex-music/yandex-music.asar\" $ELECTRON_ARGS $WAYLAND_FLAGS \"$@\"\n";
            } else if (isScript) {
                // For other shell scripts, set environment variables
                out << "# Shell script wrapper - set up environment for script\n";
                out << "# Export HERE so the script can use it\n";
                out << "export HERE=\"${HERE}\"\n";
                out << "export APPDIR=\"${HERE}\"\n";
                out << "exec \"${HERE}/" << relativePath << "\" \"$@\"\n";
            } else if (relativePath.contains("/opt/") && !relativePath.contains("google/chrome") && !relativePath.contains("steam")) {
                // Electron apps and other opt/ applications - change to their directory
                QString optDir = relativePath.section('/', 0, 1); // e.g., "opt/yandex-music"
                out << "# Electron/opt application - change to application directory\n";
                out << "cd \"${HERE}/" << optDir << "\"\n";
                out << "exec \"${HERE}/" << relativePath << "\" \"$@\"\n";
            } else {
                out << "exec \"${HERE}/" << relativePath << "\" \"$@\"\n";
            }
        }
    } else if (!metadata.executables.isEmpty()) {
        QFileInfo execInfo(metadata.executables.first());
        QString execName = execInfo.fileName();
        QString execPath = execInfo.absoluteFilePath();
        if (execName.endsWith(".jar")) {
            out << "JAVA=\"\"\n";
            out << "for jre_path in \"${HERE}/usr/games\"/*/lib/jvm/jre/bin/java \"${HERE}/usr/lib\"/*/jre/bin/java \"${HERE}/opt\"/*/jre/bin/java; do\n";
            out << "    if [ -f \"$jre_path\" ]; then\n";
            out << "        JAVA=\"$jre_path\"\n";
            out << "        break\n";
            out << "    fi\n";
            out << "done\n";
            out << "if [ -z \"$JAVA\" ]; then\n";
            out << "    JAVA=\"java\"\n";
            out << "fi\n";
            QString jarRelativePath = execPath;
            if (jarRelativePath.contains("/data/")) {
                jarRelativePath = jarRelativePath.section("/data/", 1);
            }
            out << "exec \"$JAVA\" -jar \"${HERE}/" << jarRelativePath << "\" \"$@\"\n";
        } else {
            // Determine path for regular executable
            QString relativePath;
            if (execPath.contains("/opt/google/chrome/")) {
                relativePath = "opt/google/chrome/" + execName;
            } else if (execPath.contains("/opt/steam/")) {
                relativePath = "opt/steam/" + execName;
            } else if (execPath.contains("/opt/")) {
                int optPos = execPath.indexOf("/opt/");
                if (optPos >= 0) {
                    QString afterOpt = execPath.mid(optPos + 1);
                    if (afterOpt.contains("/data/")) {
                        afterOpt = afterOpt.section("/data/", 1);
                    }
                    relativePath = afterOpt;
                } else {
                    relativePath = QString("usr/bin/%1").arg(execName);
                }
            } else {
                relativePath = QString("usr/bin/%1").arg(execName);
            }
            
            // Check if it's a shell script that might need special handling
            bool isScript = execName.endsWith(".sh") || 
                           (relativePath.contains("/usr/bin/") && (execName.contains("yandex") || execName.contains("music")));
            
            // For Chrome, use wrapper script
            if (execName == "chrome" && relativePath.contains("opt/google/chrome")) {
                out << "# Chrome wrapper - set up sandbox and run from correct directory\n";
                out << "# Note: chrome-sandbox requires setuid, which may not work in AppImage\n";
                out << "# Chrome will fall back to --no-sandbox mode if needed\n";
                out << "if [ -f \"${HERE}/opt/google/chrome/chrome-sandbox\" ]; then\n";
                out << "    # Try to set setuid bit (may fail in AppImage, that's OK)\n";
                out << "    chmod 4755 \"${HERE}/opt/google/chrome/chrome-sandbox\" 2>/dev/null || true\n";
                out << "fi\n";
                out << "cd \"${HERE}/opt/google/chrome\"\n";
                out << "# Run Chrome - it will handle sandbox issues automatically\n";
                out << "exec \"${HERE}/" << relativePath << "\" \"$@\"\n";
            } else if ((execName.contains("yandex") && execName.contains("music")) || 
                       (relativePath.contains("/usr/bin/") && execName.contains("yandex"))) {
                // For Yandex Music, directly launch Electron instead of using the wrapper script
                out << "# Yandex Music - launch Electron directly\n";
                out << "CONFIG_HOME=\"${XDG_CONFIG_HOME:-$HOME/.config}\"\n";
                out << "CONFIG_FILE=\"${YANDEX_MUSIC_CONFIG:-$CONFIG_HOME/yandex-music.conf}\"\n";
                out << "\n";
                out << "# Copy default config if needed\n";
                out << "if [ ! -f \"$CONFIG_FILE\" ]; then\n";
                out << "    mkdir -p \"$(dirname \"$CONFIG_FILE\")\"\n";
                out << "    if [ -f \"${HERE}/usr/lib/yandex-music/default.conf\" ]; then\n";
                out << "        cp \"${HERE}/usr/lib/yandex-music/default.conf\" \"$CONFIG_FILE\"\n";
                out << "    fi\n";
                out << "fi\n";
                out << "\n";
                out << "# Set Wayland flags if needed\n";
                out << "WAYLAND_FLAGS=\"\"\n";
                out << "if [ \"$XDG_SESSION_TYPE\" == \"wayland\" ]; then\n";
                out << "    WAYLAND_FLAGS=\"--ozone-platform=wayland\"\n";
                out << "fi\n";
                out << "\n";
                out << "# Set environment variables\n";
                out << "export TRAY_ENABLED=${TRAY_ENABLED:-0}\n";
                out << "export ALWAYS_LEAVE_TO_TRAY=${ALWAYS_LEAVE_TO_TRAY:-0}\n";
                out << "export DEV_TOOLS=${DEV_TOOLS:-0}\n";
                out << "export CUSTOM_TITLE_BAR=${CUSTOM_TITLE_BAR:-0}\n";
                out << "export VIBE_ANIMATION_MAX_FPS=${VIBE_ANIMATION_MAX_FPS:-25}\n";
                out << "\n";
                out << "# Launch Electron directly\n";
                out << "exec \"${HERE}/usr/lib/yandex-music/electron/electron\" \"${HERE}/usr/lib/yandex-music/yandex-music.asar\" $ELECTRON_ARGS $WAYLAND_FLAGS \"$@\"\n";
            } else if (isScript) {
                // For other shell scripts, set environment variables
                out << "# Shell script wrapper - set up environment for script\n";
                out << "# Export HERE so the script can use it\n";
                out << "export HERE=\"${HERE}\"\n";
                out << "export APPDIR=\"${HERE}\"\n";
                out << "exec \"${HERE}/" << relativePath << "\" \"$@\"\n";
            } else if (relativePath.contains("/opt/") && !relativePath.contains("google/chrome") && !relativePath.contains("steam")) {
                // Electron apps and other opt/ applications - change to their directory
                QString optDir = relativePath.section('/', 0, 1); // e.g., "opt/yandex-music"
                out << "# Electron/opt application - change to application directory\n";
                out << "cd \"${HERE}/" << optDir << "\"\n";
                out << "exec \"${HERE}/" << relativePath << "\" \"$@\"\n";
            } else {
                out << "exec \"${HERE}/" << relativePath << "\" \"$@\"\n";
            }
        }
    }
    
    file.close();
    
    return SubprocessWrapper::setExecutable(appRunPath);
}

